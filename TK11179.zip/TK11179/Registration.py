#! C:/Program Files/Python36/python.exe
print("Content-Type: text/html\n")
print()
import cgi
import cgitb;cgitb.enable()
import numpy as np

import os
import numpy as np
data=cgi.FieldStorage()
name =data.getvalue('name')
email =data.getvalue('email')
number =data.getvalue('number')
pwd=data.getvalue('pwd')
cpwd=data.getvalue('cpwd')
address =data.getvalue('address')

if pwd==cpwd:

    import mysql.connector
    con=mysql.connector.connect(user='root',password='',host='localhost',db='Croprecommendation')
    cur=con.cursor()
    sql="insert into reg (name,email,number,pwd,cpwd,address) values('%s','%s','%s','%s','%s','%s')"%(name,email,number,pwd,cpwd,address)
    cur.execute(sql)
    con.commit()
    cur.close()
    con.close()
    redirecturl1 = "regcomp.html"
    redirecturl = redirecturl1
    print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl) + '"/>')
else:
    redirecturl1 = "regun.html"
    redirecturl = redirecturl1
    print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl) + '"/>')
