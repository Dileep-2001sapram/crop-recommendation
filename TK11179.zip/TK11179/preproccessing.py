import pandas as pd
import numpy as np
full_data=pd.read_csv(r"C:\xampp\htdocs\CropRecommendation\filesuploading\Crop_recommendation.csv")
#Top 5 row data
full_data.head()
# N   P   K  temperature   humidity        ph    rainfall label
# 0  90  42  43    20.879744  82.002744  6.502985  202.935536  rice
# 1  85  58  41    21.770462  80.319644  7.038096  226.655537  rice
# 2  60  55  44    23.004459  82.320763  7.840207  263.964248  rice
# 3  74  35  40    26.491096  80.158363  6.980401  242.864034  rice
# 4  78  42  42    20.130175  81.604873  7.628473  262.717340  rice

#Checking Null Values In Dataset
full_data.isnull().head()
#        N      P      K  temperature  humidity     ph  rainfall  label
# 0  False  False  False        False     False  False     False  False
# 1  False  False  False        False     False  False     False  False
# 2  False  False  False        False     False  False     False  False
# 3  False  False  False        False     False  False     False  False
# 4  False  False  False        False     False  False     False  False

# Checking Null Values Count In Data Set
# If Data Set Has Any Null Values We Have to Use data transformation and data integration steps
full_data.isnull().sum().sum()
# 0

# Because Of There Is No Null Values In the Data Set We need not to perform those Steps

# Example Of Data Transformation Example

df=pd.DataFrame(np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]]), columns=['a', 'b', 'c'])
#Beore tranform the Data
#    a  b  c
# 0  1  2  3
# 1  4  5  6
# 2  7  8  9

df.transform(func = lambda x : x * 10)
#After Tranform The Data
#     a   b   c
# 0  10  20  30
# 1  40  50  60
# 2  70  80  90

#Example Of Data integration or Fillaing the data with some other Data

df=pd.DataFrame(np.array([[1, 2, 7], [4,0, 6], [2, 8, 9]]), columns=['a', 'b', 'c'])
#Before Data Integration step
#    a  b  c
# 0  1  2  3
# 1  4  5  6
# 2  7  8  9


NaN=np.nan
df["New_Column"]=NaN
# Here we Are Creating Null Values In To DataSet

#   a  b  c  New_Column
# 0  1  2  7         NaN
# 1  4  0  6         NaN
# 2  2  8  9         NaN

# Data Integration

df.fillna(4)
# here we are replacing data into dta
#   a  b  c  New_Column
# 0  1  2  7         4.0
# 1  4  0  6         4.0
# 2  2  8  9         4.0
