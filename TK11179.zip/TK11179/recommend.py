#! C:/Program Files/Python36/python.exe
print("Content-Type: text/html\n")
print()
import cgi
import cgitb;cgitb.enable()
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split

from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
import pandas as pd
full_data=pd.read_csv(r"C:\xampp\htdocs\CropRecommendation\filesuploading\Crop_recommendation.csv")

full_data['label'] = le.fit_transform(full_data['label'])
row_val=full_data.values.tolist()
y=full_data["label"]
X = full_data.iloc[:,:-1]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.20)
data=cgi.FieldStorage()
a=float(data.getvalue('n'))
b=float(data.getvalue('p'))
c=float(data.getvalue('k'))
d=float(data.getvalue('t'))
e=float(data.getvalue('h'))
f=float(data.getvalue('ph'))
g=float(data.getvalue('r'))
print(a,b,c,d,e,f,g)
val = [[float(a), float(b), float(c), float(d), float(e), float(f), float(g)]]
model1 = KNeighborsClassifier()
model1.fit(X_train, y_train)
pred = model1.predict(val)
le = LabelEncoder()
pred1 = le.fit_transform(pred)
pred1 = le.inverse_transform(pred1)
print(pred1)
pred2=pred1[0]
print(pred2)
# print(kjhh)
redirecturl1 = "output.html?dpr="+str(pred2)
print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl1) + '"/>')

