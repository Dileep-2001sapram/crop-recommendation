#! C:/Program Files/Python36/python.exe
print("Content-Type: text/html\n")
print()
import cgi
import os
import os
import os, glob

from werkzeug.utils import secure_filename

import shutil
import cgitb;cgitb.enable()
filename=cgi.FieldStorage()

fileitem = filename["file"]
if fileitem.filename:
    dir7 = r'C:/xampp/htdocs/CropRecommendation/filesuploading'
    filelist = glob.glob(os.path.join(dir7, "*"))
    for f in filelist:
        print(f)
        
        os.remove(f)
    fn = os.path.basename(fileitem.filename)
    open('C:/xampp/htdocs/CropRecommendation/filesuploading/' + fn, 'wb').write(fileitem.file.read())
    message = 'The file "' + fn + '" was uploaded successfully'
    redirecturl1 = "uploaded.html"
    print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl1) + '"/>')
else:
   message = 'No file was uploaded'

# if fileitem.filename:
#     fn = os.path.basename(fileitem.filename)
#     shutil.rmtree('C:/xampp/htdocs/CropRecommendation/filesuploading')
#     os.mkdir('C:/xampp/htdocs/CropRecommendation/filesuploading')
#     filename.save(os.path.join('C:/xampp/htdocs/CropRecommendation/filesuploading', secure_filename(filename.filename)))
#     mypath = filename.save(os.path.join('C:/xampp/htdocs/CropRecommendation/filesuploading/', fn))
#     redirecturl1 = "uploaded.html"
#     print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl1) + '"/>')


