#! C:/Program Files/Python36/python.exe
print("Content-Type: text/html\n")
print()
import cgi
import cgitb;cgitb.enable()

data=cgi.FieldStorage()

email =data.getvalue('email')
pwd =data.getvalue('pwd')

import mysql.connector
con=mysql.connector.connect(user='root',password='',host='localhost',db='Croprecommendation')
cursor=con.cursor()
sql="select email,pwd from reg where email='%s' and pwd='%s' and status='accepted' "%(email,pwd)


X=cursor.execute(sql)

Results=cursor.fetchall()
con.commit()
print("1111")
try:
    # print(j)

    for row in Results:
        print(row)
        if row[0]==email and row[1]==pwd:
            print(email,"j",pwd)
            redirecturl1 = "Crophome.html"
            redirecturl = redirecturl1
            print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl) + '"/>')

        else:

            redirecturl1 = "invalid.html"
            print("rrr")
            print(lk)
            redirecturl = redirecturl1
            print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl) + '"/>')
        
except:
    # print(qq)
    redirecturl1 = "Crophome.html"
    redirecturl = redirecturl1
    print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl) + '"/>')
