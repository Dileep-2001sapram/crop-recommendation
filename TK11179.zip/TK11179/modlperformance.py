#! C:/Program Files/Python36/python.exe
print("Content-Type: text/html\n")
print()
import cgi
import cgitb;cgitb.enable()
from sklearn.naive_bayes import GaussianNB
import pandas as pd

import xgboost as xgb
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
data=cgi.FieldStorage()
num =data.getvalue('algo')
print(num)
num1=int(num)
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
full_data=pd.read_csv(r"C:\xampp\htdocs\CropRecommendation\filesuploading\Crop_recommendation.csv")

full_data['label'] = le.fit_transform(full_data['label'])
row_val=full_data.values.tolist()
y=full_data["label"]
X = full_data.iloc[:,:-1]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.70)
if num1==0:
    print("!!!")

    redirecturl1 = "modelperformance.html"
    print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl1) + '"/>')

if num1==1:
    print("@@@@@@@@@@@")
    model1 = xgb.XGBClassifier()
    model1.fit(X_train, y_train)
    model1.predict(X_test)
    score1 = model1.score(X_test, y_test)
    socr=str(score1)

    redirecturl1 = "modelperformance_new.html?dpr="+socr+"__"+"XG Boost"
    print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl1) + '"/>')

elif num1 == 2:
    model2 = KNeighborsClassifier()
    model2.fit(X_train, y_train)
    model2.predict(X_test)
    score2 = model2.score(X_test, y_test)
    scr2=str(score2)
    redirecturl1 = "modelperformance_new.html?dpr=" + scr2+"__"+"K Neirest Neighbour"
    print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl1) + '"/>')

elif num1 == 3:
    model3 = DecisionTreeClassifier(max_leaf_nodes=20)
    model3.fit(X_train, y_train)
    model3.predict(X_test)
    score3 = model3.score(X_test, y_test)
    scr4=str(score3)
    redirecturl1 = "modelperformance_new.html?dpr=" + scr4+"__"+"Decision Tree"
    print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl1) + '"/>')

elif num1 == 4:
    model4 = SVC(coef0=0.8)
    model4.fit(X_train, y_train)
    model4.predict(X_test)
    score4 = model4.score(X_test, y_test)
    scr5=str(score4)
    redirecturl1 = "modelperformance_new.html?dpr=" + scr5+"__"+"Support Vector Machine"
    print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl1) + '"/>')

elif num1==5:
    model = GaussianNB()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    accuracyscore2 = model.score(X_test, y_test)

    score6=str(accuracyscore2)
    redirecturl1 = "modelperformance_new.html?dpr=" + score6+"__"+"Naive Bayes Algorithm"
    print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl1) + '"/>')








