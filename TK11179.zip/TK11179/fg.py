#! C:/Program Files/Python36/python.exe
print("Content-Type: text/html\n")
print()
import cgi
import cgitb;cgitb.enable()
import numpy as np
from sklearn.model_selection import train_test_split
from train import val
import pandas as pd
df=pd.read_csv(r"C:\xampp\htdocs\CropRecommendation\filesuploading\Crop_recommendation.csv")
X = df.iloc[:,:-1]
y = df.iloc[:,-1]
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=val, random_state=10)
print(x_train.head())
c="kjhkjh"