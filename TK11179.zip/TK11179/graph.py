import seaborn as sns
import pandas as pd
import xgboost as xgb
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
data=cgi.FieldStorage()
num =data.getvalue('algo')
print(num)
num1=int(num)
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
full_data=pd.read_csv(r"C:\xampp\htdocs\CropRecommendation\filesuploading\Crop_recommendation.csv")

full_data['label'] = le.fit_transform(full_data['label'])
row_val=full_data.values.tolist()
y=full_data["label"]
X = full_data.iloc[:,:-1]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.70)

model1 = xgb.XGBClassifier()
model1.fit(X_train, y_train)
model1.predict(X_test)
score1 = model1.score(X_test, y_test)
model2 = KNeighborsClassifier()
model2.fit(X_train, y_train)
model2.predict(X_test)
score2 = model2.score(X_test, y_test)
model3 = DecisionTreeClassifier(max_leaf_nodes=20)
model3.fit(X_train, y_train)
model3.predict(X_test)
score3 = model3.score(X_test, y_test)
model4 = SVC(coef0=0.8)
model4.fit(X_train, y_train)
model4.predict(X_test)
score4 = model4.score(X_test, y_test)
scores = pd.DataFrame({'Models':['Xgboost','KNN','Decision Tree','Support Vector Machines'],'Scores':[score1,score2,score3,score4]})
sns.barplot(x = scores.Models,y = scores.Scores)
