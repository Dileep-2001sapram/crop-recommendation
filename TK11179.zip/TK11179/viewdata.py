#! C:/Program Files/Python36/python.exe
print("Content-Type: text/html\n")
print()
import cgi
import flask
from flask import render_template
import pandas as pd

full_data=pd.read_csv(r"C:\xampp\htdocs\CropRecommendation\filesuploading\Crop_recommendation.csv")
full_data1=full_data.head(30)
# full_data1.v
row_val=full_data1.values.tolist()
redirecturl1="View_data.html"

print('<meta http-equiv="refresh" content="0;url=' + str(redirecturl1) + '"/>')

